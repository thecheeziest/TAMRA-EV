import React from 'react';

const TamraevMapItem = () => {
    return (
        <div>
            
        </div>
    );
};

export default TamraevMapItem;